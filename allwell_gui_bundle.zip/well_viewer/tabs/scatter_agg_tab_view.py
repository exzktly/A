"""Scatter Plot: Aggregate tab builder (Qt port)."""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QAction
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QHBoxLayout, QLabel, QMenu, QPushButton, QVBoxLayout,
    QWidget, QWidgetAction,
)

from well_viewer.ui_helpers import (
    attach_plot_toolbar, btn_primary, make_plot_with_right_dock,
)


def build_scatter_agg_tab(app, parent: QWidget) -> None:
    from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
    from matplotlib.figure import Figure
    layout = parent.layout()
    if layout is None:
        layout = QVBoxLayout(parent)
        parent.setLayout(layout)
    layout.setContentsMargins(0, 0, 0, 0)

    plot_area, layout, app._scatter_agg_export_dock = make_plot_with_right_dock(parent)
    parent = plot_area

    ctrl = QWidget(parent)
    ctrl.setObjectName("TabCtrl")
    cl = QHBoxLayout(ctrl)
    cl.setContentsMargins(10, 6, 10, 6)

    cl.addWidget(QLabel("X-axis:", ctrl))
    app._scatter_agg_stat_x_cb = QComboBox(ctrl)
    app._scatter_agg_stat_x_cb.addItems(["Mean Fluorescence"])
    app._scatter_agg_stat_x_cb.currentIndexChanged.connect(
        lambda _i: app._redraw_scatter_agg()
    )
    cl.addWidget(app._scatter_agg_stat_x_cb)
    app._scatter_agg_stat_x_var = app._scatter_agg_stat_x_cb

    cl.addWidget(QLabel("Y-axis:", ctrl))
    app._scatter_agg_stat_y_cb = QComboBox(ctrl)
    app._scatter_agg_stat_y_cb.addItems(["Fraction On"])
    app._scatter_agg_stat_y_cb.currentIndexChanged.connect(
        lambda _i: app._redraw_scatter_agg()
    )
    cl.addWidget(app._scatter_agg_stat_y_cb)
    app._scatter_agg_stat_y_var = app._scatter_agg_stat_y_cb

    cl.addWidget(QLabel("Timepoints:", ctrl))

    app._scatter_agg_tp_button = QPushButton("Select Timepoints", ctrl)
    app._scatter_agg_tp_button.setProperty("variant", "secondary")
    app._scatter_agg_tp_button.clicked.connect(
        lambda _=False: _open_timepoint_selector(app)
    )
    cl.addWidget(app._scatter_agg_tp_button)

    app._scatter_agg_tp_label = QLabel("(0 selected)", ctrl)
    app._scatter_agg_tp_label.setObjectName("Muted")
    cl.addWidget(app._scatter_agg_tp_label)

    app._scatter_agg_tp_selections = {}

    cl.addStretch(1)

    style_btn = QPushButton("▸", ctrl)
    style_btn.setProperty("variant", "secondary")
    style_btn.clicked.connect(lambda _=False: app._open_export_style_panel("scatter_agg"))
    cl.addWidget(style_btn)
    cl.addWidget(btn_primary(ctrl, "Export CSV", app._export_scatter_agg_data))
    layout.addWidget(ctrl)

    app._scatter_agg_fig = Figure(figsize=(8, 6), dpi=100)
    app._ax_scatter_agg = app._scatter_agg_fig.add_subplot(1, 1, 1)
    app._scatter_agg_fig.subplots_adjust(
        hspace=0.3, top=0.95, bottom=0.12, left=0.12, right=0.97,
    )

    app._scatter_agg_canvas = FigureCanvas(app._scatter_agg_fig)
    layout.addWidget(app._scatter_agg_canvas, 1)
    attach_plot_toolbar(layout, app._scatter_agg_canvas, parent, app)


def _open_timepoint_selector(app) -> None:
    """Pop up a QMenu of checkboxes below the Timepoints button."""
    menu = QMenu(app._scatter_agg_tp_button)

    checkboxes: dict[str, QCheckBox] = {}
    for tp_str in sorted(app._scatter_agg_tp_selections.keys(), key=float):
        cb = QCheckBox(tp_str, menu)
        cb.setChecked(bool(app._scatter_agg_tp_selections[tp_str]))
        checkboxes[tp_str] = cb

        def _make_handler(tp=tp_str, checkbox=cb):
            def on_toggled(checked: bool) -> None:
                app._scatter_agg_tp_selections[tp] = bool(checked)
                app._update_tp_selection_display()
                app._redraw_scatter_agg()
            return on_toggled

        cb.toggled.connect(_make_handler())
        wa = QWidgetAction(menu)
        wa.setDefaultWidget(cb)
        menu.addAction(wa)

    menu.addSeparator()

    def _set_all(value: bool) -> None:
        for tp_str, cb in checkboxes.items():
            cb.blockSignals(True)
            try:
                cb.setChecked(value)
            finally:
                cb.blockSignals(False)
            app._scatter_agg_tp_selections[tp_str] = value
        app._update_tp_selection_display()
        app._redraw_scatter_agg()

    all_action = QAction("All", menu)
    all_action.triggered.connect(lambda _=False: _set_all(True))
    menu.addAction(all_action)

    none_action = QAction("None", menu)
    none_action.triggered.connect(lambda _=False: _set_all(False))
    menu.addAction(none_action)

    btn = app._scatter_agg_tp_button
    menu.exec(btn.mapToGlobal(btn.rect().bottomLeft()))
